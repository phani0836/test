import boto3
import http.client
import base64
import ast
import yaml
import os
import re
import json
import time

os_mwaa_env_name = os.getenv("mwaa_env_name")
print("os_mwaa_env_name:", os_mwaa_env_name)
os_env_name = os.getenv("env")
print("os_env_name:", os_env_name)
mwaa_cli_command = 'dags trigger'

mwaa_client = boto3.client('mwaa')


def lambda_handler(event, context):

    print("Lambda Execution Started")
    print("Event Received")

    print(event)
    bucketName = event['Records'][0]['s3']['bucket']['name']
    objectKey = event['Records'][0]['s3']['object']['key']

    print("Bucket Name : {}".format(bucketName))
    print("Object Name : {}".format(objectKey))

    s3ObjectName = 's3://' + bucketName + '/' + objectKey
    try:
        splitPrefix = objectKey.split('/')
        print("splitPrefix is: {}".format(splitPrefix))
        jobName = splitPrefix[1]
        jobName = str(jobName)
        print("jobName is: {}".format(jobName))
        instName = splitPrefix[2]
        instName = str(instName)
        instName = instName[:-24]
        print("instName is: {}".format(instName))

        sm_prefix = "cmg-oasis-"
        sm_suffix = "-sgmakerntbk"
        sm_prefix = sm_prefix + os_env_name.lower() + "-"
        #sgmaker-automation-v-sgmakerntbk-alapatyp
        sso_suffix = sm_suffix + '-'
        sso = instName.split(sso_suffix)[1].split("/")[0]
        print("SSO :", sso)
        print("SM Split", instName.split(sm_prefix))
        group_name = instName.split(sm_prefix)[1].split(sm_suffix)[0]
        #group_name = getGroupName(instance_name)
        print("***group name***", group_name)
        sso_suffix = sm_suffix + '-'
        sso = instName.split(sso_suffix)[1].split("/")[0]
        print("sso :", sso)
        inst_name_string = "inst_name = '" + instName + "'"
        print("inst_name_string :", inst_name_string)
        yaml_bucket_string = 'yaml_bucket = "' + bucketName + '"'
        print("yaml_bucket_string :", yaml_bucket_string)
        yaml_file_string = 'yaml_file_key = "' + objectKey + '"'
        print("yaml_file_string :", yaml_file_string)

        s3_client = boto3.client('s3')

        response = s3_client.get_object(Bucket=bucketName, Key=objectKey)
        configfile = yaml.safe_load(response["Body"])
        #print(configfile)
        if configfile['dag_1']['schedule_interval'] != 'adhoc':
            on_demand = False
            print("scheduled job")
            start_date = configfile['dag_1']['start_date']
            end_date = configfile['dag_1']['end_date']
            schedule_interval = configfile['dag_1']['schedule_interval']
            print('start_date', start_date)
            print('end_date', end_date)
            print('schedule_interval :', schedule_interval)
            start_date = str(start_date).split('-')
            print(start_date)
            start_date = [ele.lstrip('0') for ele in start_date]
            print(str(start_date))
            print('start_date :', start_date)
            end_date = str(end_date).split('-')
            end_date = [ele.lstrip('0') for ele in end_date]
            print(str(end_date))
            print('end_date :', end_date)
            start_date_string = "start_date = pendulum.datetime(" + start_date[0] + \
                ', ' + start_date[1] + ', ' + start_date[2] + ", 0, 0, tz='UTC')"
            print('start_date_string :', start_date_string)
            end_date_string = "end_date = pendulum.datetime(" + end_date[0] + \
                ', ' + end_date[1] + ', ' + end_date[2] + ", 0, 0, tz='UTC')"
            print('end_date_string :', end_date_string)
            schedule_interval_string = "schedule_interval = '" + schedule_interval + "'"
            print('schedule_interval_string :', schedule_interval_string)
            job_parameters = inst_name_string + '\n' + yaml_bucket_string + '\n' + yaml_file_string + \
                '\n' + start_date_string + '\n' + end_date_string + '\n' + schedule_interval_string
            print("job_parameters :", job_parameters)

        else:
            print("on demand job")
            on_demand = True
            schedule_interval = configfile['dag_1']['schedule_interval']
            print('schedule_interval :', schedule_interval)
            start_date_string = "start_date = days_ago(1)"
            print(start_date_string)
            schedule_interval_string = "schedule_interval = None"
            print('schedule_interval_string :', schedule_interval_string)
            end_date_string = "end_date = None"
            print('end_date_string :', end_date_string)

            job_parameters = inst_name_string + '\n' + yaml_bucket_string + '\n' + yaml_file_string + \
                '\n' + start_date_string + '\n' + end_date_string + '\n' + schedule_interval_string
            print("job_parameters :", job_parameters)

        file = "jupter_lab_yaml/sample_dag.py"
        response = s3_client.get_object(Bucket=bucketName, Key=file)

        data = []
        it = response['Body'].iter_lines()
        #print(it)
        for i, line in enumerate(it):
            #print(line)
            modify = line.decode('utf-8').replace("#job_parameters", job_parameters)
            data.append(modify)
        dag_key = 'dags/' + group_name + '/' + sso + '/' + jobName + '/' + jobName + '.py'
        print("dag_key:", dag_key)
        r = s3_client.put_object(Body='\n'.join(data), Bucket=bucketName, Key=dag_key)
        #print("r:",r)

        if on_demand:
            print("Wait for airflow celery executor to register the job within airflow")
            time.sleep(300)
            print("execute the dag via CLI")
            # get web token
            mwaa_cli_token = mwaa_client.create_cli_token(Name=os_mwaa_env_name)
            print("mwaa_cli_token:", mwaa_cli_token)
            conn = http.client.HTTPSConnection(mwaa_cli_token['WebServerHostname'])
            print("conn:", conn)
            payload = "dags trigger " + jobName
            print("payload:", payload)
            headers = {
                'Authorization': 'Bearer ' + mwaa_cli_token['CliToken'],
                'Content-Type': 'text/plain'
            }
            print("headers:", headers)
            conn.request("POST", "/aws_mwaa/cli", payload, headers)
            res = conn.getresponse()
            data = res.read()
            dict_str = data.decode("UTF-8")
            mydata = ast.literal_eval(dict_str)

    except Exception as e:
        print("Exception while running lambda")
        print(e)

    #return base64.b64decode(mydata['stdout'])
    return
